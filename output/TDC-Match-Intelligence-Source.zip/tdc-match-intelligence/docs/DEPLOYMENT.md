# Vercel deployment handoff

The app is ready for a Node.js/Vercel deployment. It has been built and tested locally against PostgreSQL. This file does not claim that a public URL already exists.

## Prerequisites

- A GitHub repository under the submitter's account.
- A Vercel project importing that repository.
- A dedicated managed PostgreSQL database with a connection string compatible with `pg`.
- Optional Gemini API key configured through the hosting environment-variable UI.

Never commit `.env`, database files, access tokens, or real client records.

## Deploy

1. Push this source tree, including `package-lock.json`, `prisma/`, and `.env.example`. Exclude `node_modules`, `.next`, `.local-db`, and `.env` (already ignored).
2. Import into Vercel as **Next.js**, Node.js 24.x. Build command: `npm run build`.
3. Set `DATABASE_URL` to the managed database connection string. Preserve provider TLS settings. If migrations require a direct URL, temporarily use that connection for the migration command; use the provider's appropriate pooled connection at runtime.
4. For an unrestricted synthetic demo, set `DEMO_ANALYZER=true` and leave `GEMINI_API_KEY` unset. The app will label this mode honestly.
5. Run `npm run db:migrate` against the dedicated remote database. Then run `npm run db:seed` once. If `NODE_ENV=production`, explicitly set `ALLOW_DEMO_RESET=true` for that seed command only. Seeding destroys this application's existing demo records.
6. Deploy and run the reviewer journey from the README. Refresh after recording feedback to verify remote persistence.
7. Copy the real public URL and GitHub URL into the submission message. Regenerate the submission PDF if links are inserted into the written response.

The embedded PostgreSQL package is a local-development convenience. Do not start it on Vercel and do not use localhost as a cloud database URL.

## Enable and verify live AI

Use deployment access protection for a private assessment demo before adding `GEMINI_API_KEY`; there is no app authentication or durable public rate limiter in this MVP. Set `DEMO_ANALYZER=false` and the fixed `gemini-2.5-flash` model. Redeploy. Analyze the example and verify the response says **Gemini 2.5 Flash draft**, not **Demo rules**. Save only after reviewing the extracted evidence.

Gemini outages leave manual categorization available. Avoid claiming live AI was tested until an actual request succeeds with your configured account.

## Submission status

- Local production build: verified.
- Persistent local PostgreSQL: verified.
- Public URL: awaiting hosting setup.
- GitHub URL: awaiting repository setup.
- Live Gemini request: awaiting a configured key.
- Resume: supply your own current resume; none was attached.

The original assessment accepts screenshots or a recording as prototype evidence, so the screenshots in `docs/screenshots/` remain usable even before hosting is complete.
