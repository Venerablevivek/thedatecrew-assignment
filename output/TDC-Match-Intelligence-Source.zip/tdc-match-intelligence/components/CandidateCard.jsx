"use client";
import { useState } from "react";
import {
  Check,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  AlertTriangle,
  Bookmark,
  ArrowUpRight,
  Send,
  X,
} from "lucide-react";
import { Avatar, Badge, BusyButton } from "./ui";
import { reciprocalCheck } from "@/lib/match-tools";
import Link from "next/link";
import { pretty, WEIGHTS } from "@/lib/matching";
export default function CandidateCard({
  match,
  index,
  onAction,
  onReject,
  busy,
  client,
  compared,
  compareDisabled,
  onCompare,
  onTool,
}) {
  const [details, setDetails] = useState(false);
  const p = match.profile,
    status = match.recommendation?.status;
  const reciprocal = client ? reciprocalCheck(client, p) : null;
  const next = {
    SHARED: ["ACCEPTED", "Record acceptance"],
    ACCEPTED: ["CONTACT_SHARED", "Mark contacts shared"],
    CONTACT_SHARED: ["CONVERSATION_STARTED", "Mark conversation started"],
    CONVERSATION_STARTED: ["MEETING_FIXED", "Mark meeting fixed"],
    MEETING_FIXED: ["MEETING_COMPLETED", "Mark meeting completed"],
  }[status];
  return (
    <article className={`card candidate-card ${!match.eligible ? "ineligible" : ""}`}>
      <div className="candidate-header">
        <Avatar name={p.name} index={index} large />
        <div className="candidate-name">
          <h2>{p.name}</h2>
          <p>
            {p.age} · {p.occupation}
          </p>
          <span>{p.city}</span>
        </div>
        {match.eligible ? (
          <div className="score">
            <strong>
              {match.score}
              <small>/100</small>
            </strong>
            <Badge tone={match.score >= 85 ? "green" : "violet"}>{match.label}</Badge>
          </div>
        ) : (
          <Badge tone={match.status === "BLOCKED" ? "rose" : "amber"}>{match.label}</Badge>
        )}
      </div>
      <div className={`eligibility ${match.eligible ? "pass" : "fail"}`}>
        {match.eligible ? <ShieldCheck size={15} /> : <AlertTriangle size={15} />}
        <span>
          {match.eligible ? "Passes the client’s hard requirements" : match.warnings.join(" · ")}
        </span>
        {status && <Badge>{pretty(status)}</Badge>}
      </div>
      {match.eligible && (
        <>
          <div className="candidate-why">
            <span className="eyebrow">WHY THIS INTRODUCTION</span>
            <p>{match.explanation}</p>
          </div>
          {details && (
            <div className="chip-row">
              {match.matched.slice(0, 5).map((t) => (
                <span className="match-chip" key={t}>
                  <Check size={12} />
                  {t}
                </span>
              ))}
            </div>
          )}
          {match.warnings.length > 0 && (
            <div className="candidate-warning">
              <AlertTriangle size={14} />
              <span>{match.warnings[0]}</span>
            </div>
          )}
          <button
            className="breakdown-toggle"
            onClick={() => setDetails(!details)}
            aria-expanded={details}
          >
            How this score was calculated
            {details ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
          </button>
          {details && (
            <div className="score-breakdown">
              {Object.entries(match.breakdown).map(([key, value]) => (
                <div key={key}>
                  <span>{pretty(key)}</span>
                  <div className="score-track">
                    <div style={{ width: `${(value / WEIGHTS[key]) * 100}%` }} />
                  </div>
                  <strong>
                    {value}
                    <small>/{WEIGHTS[key]}</small>
                  </strong>
                </div>
              ))}
              <p>{match.historyNote}</p>
              <p>A transparent ranking aid, not a probability of compatibility.</p>
            </div>
          )}
        </>
      )}
      {onTool && (
        <div className="candidate-tools">
          <label className="check-label">
            <input
              type="checkbox"
              checked={compared}
              disabled={compareDisabled || busy}
              onChange={onCompare}
            />
            Compare {p.name}
          </label>
          <button className="text-link" disabled={busy} onClick={() => onTool("compatibility")}>
            Two-sided: {pretty(reciprocal.status)}
          </button>
          {match.eligible && (
            <button
              className="text-link"
              disabled={busy || reciprocal.status === "CONFLICT"}
              onClick={() => onTool("draft")}
            >
              Draft introduction
            </button>
          )}
          {match.recommendation?.acceptedAt && (
            <Link href="/meetings" className="text-link">
              Coordinate meeting →
            </Link>
          )}
        </div>
      )}
      {reciprocal?.status === "CONFLICT" && (
        <p className="candidate-warning">
          Two-sided requirements conflict. Open the two-sided check to review before sharing.
        </p>
      )}
      <div className="candidate-actions">
        {status === "REJECTED" ? (
          <Badge tone="rose">Feedback recorded</Badge>
        ) : status === "MEETING_COMPLETED" ? (
          <Badge tone="green">
            <Check size={13} />
            Meeting completed
          </Badge>
        ) : (
          <>
            {!match.recommendation?.acceptedAt && (
              <button className="button subtle" disabled={busy} onClick={onReject}>
                <X size={15} />
                Reject
              </button>
            )}
            <div className="candidate-primary-actions">
              {match.eligible && (!status || status === "SUGGESTED") && (
                <BusyButton className="button" busy={busy} onClick={() => onAction("SHORTLISTED")}>
                  <Bookmark size={14} />
                  Shortlist
                </BusyButton>
              )}
              {match.eligible && (!status || ["SUGGESTED", "SHORTLISTED"].includes(status)) && (
                <BusyButton
                  className="button primary"
                  busy={busy}
                  disabled={busy || reciprocal?.status === "CONFLICT"}
                  onClick={() => onAction("SHARED")}
                >
                  <Send size={14} />
                  Mark shared
                </BusyButton>
              )}
              {next && (
                <BusyButton
                  className="button primary"
                  busy={busy}
                  onClick={() => onAction(next[0])}
                >
                  {next[1]}
                  <ArrowUpRight size={14} />
                </BusyButton>
              )}
            </div>
          </>
        )}
      </div>
    </article>
  );
}
