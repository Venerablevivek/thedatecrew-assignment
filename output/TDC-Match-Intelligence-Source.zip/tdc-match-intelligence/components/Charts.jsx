"use client";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from "recharts";
import { pretty } from "@/lib/matching";
const colors = ["#7960e8", "#d66596", "#429dc0", "#e0a03d", "#3caa91", "#a37ade"];
export function ReasonChart({ data }) {
  return (
    <div className="reason-chart">
      <ResponsiveContainer width="100%" height={260}>
        <BarChart
          data={data.slice(0, 6).map((r) => ({ ...r, label: pretty(r.category) }))}
          layout="vertical"
          margin={{ left: 0, right: 30, top: 8, bottom: 0 }}
        >
          <XAxis type="number" hide allowDecimals={false} />
          <YAxis
            type="category"
            dataKey="label"
            width={100}
            axisLine={false}
            tickLine={false}
            tick={{ fontSize: 14, fill: "#667085" }}
          />
          <Tooltip
            cursor={{ fill: "#f6f3f9" }}
            contentStyle={{ borderRadius: 10, border: "1px solid #e9e5e2", fontSize: 14 }}
          />
          <Bar
            dataKey="count"
            name="Feedback records"
            barSize={24}
            radius={[0, 4, 4, 0]}
            isAnimationActive={false}
          >
            {data.slice(0, 6).map((r, i) => (
              <Cell key={r.category} fill={colors[i]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
export function Funnel({ data }) {
  return (
    <div className="funnel">
      {data.map((item, i) => (
        <div
          className="funnel-row"
          key={item.stage}
          style={{ "--stage": i, "--stage-color": colors[i % colors.length] }}
        >
          <div className="funnel-label">
            <span className="step-number">0{i + 1}</span>
            {item.stage}
          </div>
          <div className="funnel-track">
            <div
              style={{
                width: `${Math.max(3, (item.value / (data[0].value || 1)) * 100)}%`,
                background: `linear-gradient(90deg, ${colors[i % colors.length]}, color-mix(in srgb, ${colors[i % colors.length]} 65%, white))`,
              }}
            />
          </div>
          <strong>{item.value.toLocaleString()}</strong>
          <span className={i === 1 ? "drop-rate" : "conversion"}>
            {i ? `${item.conversion}%` : "—"}
          </span>
        </div>
      ))}
    </div>
  );
}
