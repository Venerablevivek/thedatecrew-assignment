"use client";
import { Sparkles, ArrowUpRight, CheckCheck } from "lucide-react";
import { useResource } from "./ui";
export default function AIStatus() {
  const { data, error } = useResource("/api/ai/status");
  return (
    <section className="ai-status-card" aria-label="AI assistant status">
      <div className="ai-status-icon">
        <Sparkles size={20} />
      </div>
      <div className="ai-status-copy">
        <span className="eyebrow">YOUR REVIEW ASSISTANT</span>
        <h3>Gemini 2.5 Flash</h3>
        <p>
          {error
            ? "Status unavailable. Your matching tools still work."
            : !data
              ? "Checking configuration…"
              : data.configured
                ? "Key configured. Review every AI suggestion before using it."
                : "Ready when you are. Demo tools work while you add your API key."}
        </p>
      </div>
      <div className="ai-status-side">
        <span className={`provider-pill ${data?.configured ? "ready" : ""}`}>
          <span />
          {data?.configured ? "Key configured" : data ? "Demo mode" : "Checking"}
        </span>
        <small>
          <CheckCheck size={14} />
          Human-reviewed decisions
        </small>
      </div>
    </section>
  );
}
