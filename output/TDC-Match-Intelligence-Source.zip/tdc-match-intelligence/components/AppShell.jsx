"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  CalendarDays,
  LayoutDashboard,
  UsersRound,
  Layers3,
  MessageSquareText,
  ArrowUpRight,
  Sparkles,
  CircleHelp,
  ChevronRight,
  PanelLeftClose,
  Menu,
  X,
} from "lucide-react";
import { useState } from "react";
const items = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { href: "/assistant", label: "AI assistant", icon: Sparkles },
  { href: "/clients", label: "Clients", icon: UsersRound },
  { href: "/match-queue", label: "Match queue", icon: Layers3 },
  { href: "/meetings", label: "Meetings", icon: CalendarDays },
  { href: "/feedback", label: "Feedback & learning", icon: MessageSquareText },
];
export default function AppShell({ children }) {
  const pathname = usePathname();
  const [mobile, setMobile] = useState(false);
  const [help, setHelp] = useState(false);
  const current = items.find((i) => pathname.startsWith(i.href));
  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobile ? "is-open" : ""}`}>
        <Link href="/dashboard" className="brand" onClick={() => setMobile(false)}>
          <span className="brand-mark">
            <i />
            <i />
            <i />
          </span>
          <span>
            the date crew<span className="brand-sub">MATCH INTELLIGENCE</span>
          </span>
        </Link>
        <div className="workspace-label">WORKSPACE</div>
        <nav aria-label="Main navigation">
          {items.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              onClick={() => setMobile(false)}
              className={`nav-item ${pathname.startsWith(href) ? "active" : ""}`}
            >
              <Icon size={19} />
              {label}
              {pathname.startsWith(href) && <span className="active-dot" />}
            </Link>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-note">
            <Sparkles size={18} />
            <strong>Better together.</strong>
            <p>
              Human intuition.
              <br />A little more intelligence.
            </p>
            <Link href="/match-queue">
              Find your next introduction <ArrowUpRight size={14} />
            </Link>
          </div>
          <button className="help-button" onClick={() => setHelp(true)}>
            <CircleHelp size={18} />
            How to use this app
            <ChevronRight size={15} />
          </button>
          <div className="user">
            <span className="avatar violet">DM</span>
            <span>
              <strong>Demo Matchmaker</strong>
              <small>Internal workspace</small>
            </span>
            <PanelLeftClose size={16} />
          </div>
        </div>
      </aside>
      {mobile && (
        <button
          className="nav-overlay"
          aria-label="Close navigation"
          onClick={() => setMobile(false)}
        />
      )}
      <div className="workspace">
        <header className="topbar">
          <div className="breadcrumb">
            <button
              className="mobile-menu icon-button"
              aria-label="Open navigation"
              onClick={() => setMobile(true)}
            >
              <Menu size={20} />
            </button>
            <span>Workspace</span>
            <ChevronRight size={14} />
            <strong>{current?.label || "Overview"}</strong>
          </div>
          <div className="topbar-right">
            <span className="demo-pill">
              <span />
              Synthetic data demo
            </span>
            <span className="avatar small violet">DM</span>
          </div>
        </header>
        <main>{children}</main>
        <footer>
          Made for thoughtful introductions.<span>The Date Crew · Assessment prototype</span>
        </footer>
      </div>
      {help && (
        <div className="modal-backdrop" onClick={() => setHelp(false)}>
          <section
            className="modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="about-title"
            onClick={(e) => e.stopPropagation()}
          >
            <button className="icon-button close" aria-label="Close" onClick={() => setHelp(false)}>
              <X size={20} />
            </button>
            <Sparkles className="purple" />
            <h2 id="about-title">A thoughtful second opinion</h2>
            <p>
              This internal prototype checks known deal-breakers, ranks profiles with transparent
              rules, and turns feedback into human-reviewed signals.
            </p>
            <div className="notice">
              All people and decisions are synthetic. Scores are ranking aids, not predictions of
              relationship success.
            </div>
            <p>
              Try Ananya’s match queue, mark a profile as shared, record feedback, then review the
              resulting signal.
            </p>
            <button className="button primary" onClick={() => setHelp(false)}>
              Explore the workspace
            </button>
          </section>
        </div>
      )}
    </div>
  );
}
