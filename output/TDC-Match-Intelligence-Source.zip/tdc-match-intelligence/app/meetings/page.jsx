"use client";
import { useState } from "react";
import Link from "next/link";
import { CalendarDays, Clock3, ArrowUpRight } from "lucide-react";
import { useResource, PageHeader, Loading, ErrorState, Empty, Badge, Toast } from "@/components/ui";
import MeetingDialog from "@/components/MeetingDialog";
export default function Meetings() {
  const { data, loading, error, refresh } = useResource("/api/meetings");
  const [selected, setSelected] = useState(null),
    [filter, setFilter] = useState("all"),
    [search, setSearch] = useState(""),
    [limit, setLimit] = useState(8),
    [message, setMessage] = useState("");
  if (loading && !data) return <Loading />;
  if (error) return <ErrorState message={error} retry={refresh} />;
  if (!data) return null;
  const overdue = (r) =>
    r.meeting?.followUpAt && !r.meeting.followUpDone && new Date(r.meeting.followUpAt) < new Date();
  const rows = data.recommendations.filter(
    (r) =>
      (filter === "all" || (filter === "follow-up" ? overdue(r) : r.meeting?.status === filter)) &&
      `${r.client.name} ${r.profile.name}`.toLowerCase().includes(search.toLowerCase()),
  );
  return (
    <>
      <PageHeader
        eyebrow="MAKE SPACE FOR CONNECTION"
        title="Meetings & follow-ups"
        description="Coordinate accepted introductions, keep track of availability, and close the loop."
      />
      <div className="meeting-summary">
        <div className="card">
          <CalendarDays size={20} />
          <strong>
            {data.recommendations.filter((r) => r.meeting?.status === "SCHEDULED").length}
          </strong>
          <span>Scheduled meetings</span>
        </div>
        <div className="card">
          <Clock3 size={20} />
          <strong>{data.recommendations.filter(overdue).length}</strong>
          <span>Follow-ups due</span>
        </div>
      </div>
      <div className="queue-search">
        <input
          aria-label="Search meetings"
          placeholder="Find a client or candidate…"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setLimit(8);
          }}
        />
      </div>
      <div className="tabs meeting-tabs">
        {[
          ["all", "All accepted"],
          ["SCHEDULED", "Scheduled"],
          ["follow-up", "Follow-ups due"],
          ["COMPLETED", "Completed"],
          ["CANCELLED", "Cancelled"],
        ].map(([v, l]) => (
          <button
            key={v}
            className={filter === v ? "active" : ""}
            onClick={() => {
              setFilter(v);
              setLimit(8);
            }}
          >
            {l}
          </button>
        ))}
      </div>
      <div className="meeting-list">
        {rows.slice(0, limit).map((r) => (
          <article className="card meeting-card" key={r.id}>
            <div className="meeting-symbol">
              <CalendarDays size={22} />
            </div>
            <div>
              <span className="eyebrow">ACCEPTED INTRODUCTION</span>
              <h2>
                {r.client.name} <span className="muted">&</span> {r.profile.name}
              </h2>
              <p>
                {r.meeting?.scheduledAt
                  ? new Date(r.meeting.scheduledAt).toLocaleString()
                  : "Find a time that works for both people"}
              </p>
              {r.meeting?.location && <p>{r.meeting.location}</p>}
              <div className="chip-row">
                <Badge>{r.meeting?.status || "NOT PLANNED"}</Badge>
                {overdue(r) && <Badge tone="rose">Follow-up overdue</Badge>}
                {r.meeting?.followUpAt && (
                  <small>
                    Follow-up: {new Date(r.meeting.followUpAt).toLocaleString()}
                    {r.meeting.followUpDone ? " · Done" : ""}
                  </small>
                )}
              </div>
            </div>
            <button className="button primary" disabled={loading} onClick={() => setSelected(r)}>
              {r.meeting ? "Edit plan" : "Plan meeting"}
              <ArrowUpRight size={15} />
            </button>
          </article>
        ))}
      </div>
      {rows.length > limit && (
        <button className="button load-more" onClick={() => setLimit((n) => n + 8)}>
          Show more introductions ({rows.length - limit} remaining)
        </button>
      )}
      {!rows.length && (
        <Empty title="No meetings in this view">
          Record an acceptance in the{" "}
          <Link href="/match-queue" className="text-link">
            match queue
          </Link>{" "}
          to begin coordinating.
        </Empty>
      )}
      <p className="caption">
        Internal coordination · no calendar sync or automatic messages. Times are displayed in your
        device timezone.
      </p>
      {selected && (
        <MeetingDialog
          recommendation={selected}
          onClose={() => setSelected(null)}
          onSaved={() => {
            setSelected(null);
            refresh();
            setMessage("Meeting plan saved.");
          }}
        />
      )}
      <Toast message={message} />
    </>
  );
}
