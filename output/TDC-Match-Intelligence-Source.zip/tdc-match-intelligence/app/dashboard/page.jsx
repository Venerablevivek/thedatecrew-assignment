"use client";
import AIStatus from "@/components/AIStatus";
import { useState } from "react";
import Link from "next/link";
import {
  ArrowUpRight,
  ArrowRight,
  CalendarDays,
  CheckCheck,
  Clock3,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Info,
} from "lucide-react";
import {
  useResource,
  PageHeader,
  Loading,
  ErrorState,
  MetricCard,
  SectionTitle,
  Badge,
} from "@/components/ui";
import { Funnel, ReasonChart } from "@/components/Charts";
export default function Dashboard() {
  const { data, loading, error, refresh } = useResource("/api/dashboard");
  const [mode, setMode] = useState("scenario");
  if (loading && !data) return <Loading />;
  if (error) return <ErrorState message={error} retry={refresh} />;
  if (!data) return null;
  const scenario = mode === "scenario",
    m = data.metrics;
  const counts = [1000, 310, 210, 150, 75, 42];
  const funnel = scenario
    ? data.funnel.map((f, i) => ({
        ...f,
        value: counts[i],
        conversion: i ? Math.round((counts[i] / counts[i - 1]) * 1000) / 10 : 100,
      }))
    : data.funnel;
  return (
    <>
      <PageHeader
        eyebrow="THE BIG PICTURE"
        title="Your matchmaking overview"
        description="See what’s working, then choose a client to find their next introduction."
      >
        <span className="period">
          <CalendarDays size={16} />
          Last 30 days
        </span>
      </PageHeader>
      <section className="start-guide" aria-label="Getting started">
        <div className="start-intro">
          <span className="guide-label">YOUR NEXT STEP</span>
          <h2>Good matches start with understanding.</h2>
          <p>Follow a simple, human-led process.</p>
        </div>
        <div className="guide-links">
          <Link href="/clients">
            <span>1</span>
            <div>
              <strong>Choose a client</strong>
              <small>Understand what matters</small>
            </div>
            <ArrowUpRight size={18} />
          </Link>
          <Link href="/match-queue">
            <span>2</span>
            <div>
              <strong>Review matches</strong>
              <small>Compare suitable profiles</small>
            </div>
            <ArrowUpRight size={18} />
          </Link>
          <Link href="/feedback">
            <span>3</span>
            <div>
              <strong>Learn from feedback</strong>
              <small>Make the next match better</small>
            </div>
            <ArrowUpRight size={18} />
          </Link>
        </div>
      </section>
      <AIStatus />
      <div className="view-toolbar">
        <div className="segmented" aria-label="Dashboard dataset">
          <button className={scenario ? "selected" : ""} onClick={() => setMode("scenario")}>
            Assessment baseline
          </button>
          <button className={!scenario ? "selected" : ""} onClick={() => setMode("live")}>
            Live demo
          </button>
        </div>
        <span className="caption">
          <span className="status-dot" />
          {scenario
            ? "Provided scenario · fixed reference"
            : "Recorded decisions · updates as you work"}
        </span>
      </div>
      <div className="metrics-grid">
        <MetricCard
          title="Profile acceptance"
          value={scenario ? "31.0%" : `${m.acceptanceRate}%`}
          detail={
            scenario
              ? "310 of 1,000 shared profiles"
              : `${m.profilesAccepted} of ${m.profilesShared} shared profiles`
          }
          icon={TrendingUp}
        />
        <MetricCard
          title="Avoidable rejections"
          value={scenario ? "35%" : `${m.avoidableRejectionRate}%`}
          detail={
            scenario
              ? "Referenced an existing preference"
              : `${m.knownRejections} of ${m.rejected} explicit rejections`
          }
          icon={ShieldCheck}
          tone="rose"
        />
        <MetricCard
          title="Average search time"
          value={scenario ? "2" : "—"}
          suffix={scenario ? "hrs" : ""}
          detail={
            scenario ? "Per client, per week · reported" : "Not instrumented in this prototype"
          }
          icon={Clock3}
          tone="sand"
        />
        <MetricCard
          title="Meetings completed"
          value={scenario ? "42" : m.meetingsCompleted}
          detail={
            scenario ? "56% of the 75 meetings fixed" : "From the last 30 days’ shared cohort"
          }
          icon={CheckCheck}
          tone="mint"
        />
      </div>
      <div className="dashboard-main">
        <section className="card funnel-card">
          <SectionTitle
            title="From introduction to connection"
            subtitle="The recommendation journey, one step at a time."
          />
          <div className="funnel-head">
            <span>Stage</span>
            <span>Volume</span>
            <span>Step conversion</span>
          </div>
          <Funnel data={funnel} />
          <div className="card-foot">
            <Info size={14} />
            {scenario
              ? "69% have not reached acceptance. Pending responses are not necessarily rejections."
              : `${m.pending} shared profiles are still awaiting a decision. Later stages retain earlier milestones.`}
          </div>
        </section>
        <aside className="opportunity-card">
          <div className="eyebrow">
            <Sparkles size={15} />
            THE OPPORTUNITY
          </div>
          <h2>
            Better recommendations.
            <br />
            Before the first introduction.
          </h2>
          <div className="opportunity-number">
            35<span>%</span>
          </div>
          <p>of rejected profiles conflicted with preferences the team already knew.</p>
          <div className="opportunity-divider" />
          <p className="small">
            Start with what clients have already told us. Check deal-breakers, then let human
            judgment lead.
          </p>
          <Link href="/match-queue?clientId=ananya" className="button white">
            Review the match queue
            <ArrowRight size={16} />
          </Link>
          <small>Assessment observation · potential, not proven impact</small>
        </aside>
      </div>
      <div className="dashboard-bottom">
        <section className="card">
          <SectionTitle
            title="What we’re learning"
            subtitle="Rejection themes in reviewed demo feedback."
            link="Explore feedback"
            href="/feedback"
          />
          <ReasonChart data={data.rejectionReasons} />
          <div className="card-foot">
            Live synthetic data · one record may contain multiple reasons
          </div>
        </section>
        <section className="card">
          <SectionTitle
            title="A closer look at the team"
            subtitle={
              scenario
                ? "Acceptance rates from the assessment."
                : "Acceptance of profiles shared in this demo."
            }
          />
          <div className="matchmaker-bars">
            {data.matchmakers.map((mm, i) => {
              const value = scenario ? [44, 21][i] : mm.acceptanceRate;
              return (
                <div key={mm.id}>
                  <div className="spread">
                    <span>
                      <span className={`mini-dot mm-${i}`} />
                      {mm.name}
                    </span>
                    <strong>{value}%</strong>
                  </div>
                  <div className="team-track">
                    <div style={{ width: `${value}%`, background: i ? "#b9a9d7" : "#8170e9" }} />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="subtle-note">
            <Info size={16} />
            <p>
              A starting point for investigation. Client mix and sample size can explain
              differences.
            </p>
          </div>
        </section>
      </div>
      <section className="next-action">
        <div className="icon-tile">
          <Sparkles size={21} />
        </div>
        <div>
          <strong>A preference worth a second look</strong>
          <p>Ananya’s acceptance history suggests location may be more flexible than stated.</p>
        </div>
        <Link href="/clients/ananya" className="text-link">
          Review client intelligence
          <ArrowUpRight size={17} />
        </Link>
      </section>
    </>
  );
}
