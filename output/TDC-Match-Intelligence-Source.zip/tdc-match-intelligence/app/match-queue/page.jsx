"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { ShieldCheck, Sparkles, SlidersHorizontal, ArrowUpRight } from "lucide-react";
import {
  useResource,
  PageHeader,
  Loading,
  ErrorState,
  request,
  Toast,
  Badge,
  Empty,
} from "@/components/ui";
import {
  CompareDialog,
  WhatIfDialog,
  IntroductionDialog,
  CompatibilityDialog,
} from "@/components/MatchTools";
import CandidateCard from "@/components/CandidateCard";
import FeedbackModal from "@/components/FeedbackModal";
export default function MatchQueue() {
  const [compareIds, setCompareIds] = useState([]),
    [tool, setTool] = useState(null);
  const [clientId, setClientId] = useState("ananya"),
    [filter, setFilter] = useState("eligible"),
    [sort, setSort] = useState("score"),
    [limit, setLimit] = useState(8),
    [search, setSearch] = useState(""),
    [selected, setSelected] = useState(null),
    [busyId, setBusyId] = useState(null),
    [message, setMessage] = useState(""),
    [actionError, setActionError] = useState("");
  const clients = useResource("/api/clients"),
    resource = useResource(`/api/match-queue?clientId=${clientId}`);
  useEffect(() => {
    const value = new URLSearchParams(window.location.search).get("clientId");
    if (value) setClientId(value);
  }, []);
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const profileId = params.get("profileId");
    if (!profileId || !resource.data || resource.data.client.id !== clientId) return;
    const match = resource.data.matches.find((m) => m.profile.id === profileId);
    if (!match) return;
    setSearch(match.profile.name);
    setFilter(
      match.recommendation && match.recommendation.status !== "SHORTLISTED"
        ? "history"
        : match.eligible
          ? "eligible"
          : "review",
    );
  }, [resource.data, clientId]);
  useEffect(() => {
    if (!message) return;
    const t = setTimeout(() => setMessage(""), 4500);
    return () => clearTimeout(t);
  }, [message]);
  async function action(match, action) {
    setBusyId(match.profile.id);
    setActionError("");
    try {
      await request("/api/recommendations", "POST", {
        clientId,
        profileId: match.profile.id,
        action,
      });
      setMessage(
        action === "SHARED"
          ? "Marked as shared. No email was sent."
          : "Decision saved. The client history is up to date.",
      );
      resource.refresh();
    } catch (e) {
      setActionError(e.message);
    } finally {
      setBusyId(null);
    }
  }
  const { data, loading, error, refresh } = resource;
  if ((loading && !data) || (data && data.client.id !== clientId))
    return error ? <ErrorState message={error} retry={refresh} /> : <Loading />;
  if (error) return <ErrorState message={error} retry={refresh} />;
  if (!data) return null;
  const all = data.matches,
    available = all.filter((m) => !m.recommendation || m.recommendation.status === "SHORTLISTED"),
    eligible = available.filter((m) => m.eligible),
    blocked = available.filter((m) => !m.eligible);
  let shown =
    filter === "eligible"
      ? eligible
      : filter === "review"
        ? blocked
        : all.filter((m) => m.recommendation);
  shown = shown.filter((m) =>
    `${m.profile.name} ${m.profile.city} ${m.profile.occupation}`
      .toLowerCase()
      .includes(search.toLowerCase()),
  );
  if (sort === "name")
    shown = [...shown].sort((a, b) => a.profile.name.localeCompare(b.profile.name));
  return (
    <>
      <PageHeader
        eyebrow="CURATED WITH CONTEXT"
        title="Find the next introduction"
        description="Choose a client, compare suitable profiles, and decide who to introduce."
      >
        <Badge tone="violet">
          <ShieldCheck size={13} />
          You make the final decision
        </Badge>
      </PageHeader>
      <div className="queue-toolbar">
        <label>
          Matching for
          <select
            aria-label="Matching for"
            value={clientId}
            onChange={(e) => {
              setClientId(e.target.value);
              setCompareIds([]);
              setTool(null);
              setLimit(8);
              setActionError("");
            }}
          >
            {clients.data?.clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </label>
        <Link href={`/clients/${clientId}`} className="text-link">
          Client intelligence
          <ArrowUpRight size={15} />
        </Link>
        <label className="sort-control">
          Sort by
          <select aria-label="Sort matches" value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="score">Best match</option>
            <option value="name">Name</option>
          </select>
        </label>
      </div>
      <Link
        href={`/assistant?clientId=${encodeURIComponent(clientId)}`}
        className="assistant-entry"
      >
        <Sparkles size={17} />
        <span>
          Need a second pair of eyes? <strong>Ask your matchmaker assistant</strong>
        </span>
        <ArrowUpRight size={16} />
      </Link>
      <section className="match-toolstrip" aria-label="Matching tools">
        <div>
          <span className="eyebrow">A LITTLE MORE PERSPECTIVE</span>
          <strong>Explore before you decide.</strong>
        </div>
        <button className="button" onClick={() => setTool({ type: "preview" })}>
          What-if preview
        </button>
        <button
          className="button primary"
          disabled={compareIds.length < 2}
          onClick={() => setTool({ type: "compare" })}
        >
          Compare profiles ({compareIds.length}/3)
        </button>
        {compareIds.length > 0 && (
          <button className="text-link" onClick={() => setCompareIds([])}>
            Clear selection
          </button>
        )}
        <small>Select two or three profiles below to compare.</small>
      </section>
      <div className="queue-search">
        <input
          aria-label="Search candidate profiles"
          placeholder="Search profiles by name, city, or profession…"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setLimit(8);
          }}
        />
      </div>
      <div className="queue-summary">
        <span>
          <ShieldCheck size={17} />
          <strong>{eligible.length}</strong>eligible introductions
        </span>
        <span>
          <strong>{blocked.length}</strong>need review or have conflicts
        </span>
        <span>
          <strong>{all.length}</strong>profiles checked
        </span>
      </div>
      <div className="tabs queue-tabs">
        {[
          ["eligible", "Eligible queue", eligible.length],
          ["review", "Conflicts & unknowns", blocked.length],
          ["history", "Decision history", all.filter((m) => m.recommendation).length],
        ].map(([key, label, count]) => (
          <button
            key={key}
            className={filter === key ? "active" : ""}
            onClick={() => {
              setFilter(key);
              setLimit(8);
            }}
          >
            {label}
            <span>{count}</span>
          </button>
        ))}
      </div>
      {actionError && (
        <div className="notice error-text" role="alert">
          {actionError}
        </div>
      )}
      {loading && <div className="caption">Refreshing recommendations…</div>}
      <div className="queue-layout">
        <div className="stack">
          {shown.slice(0, limit).map((m, i) => (
            <CandidateCard
              key={m.profile.id}
              match={m}
              client={data.client}
              compared={compareIds.includes(m.profile.id)}
              compareDisabled={!compareIds.includes(m.profile.id) && compareIds.length >= 3}
              onCompare={() =>
                setCompareIds((ids) =>
                  ids.includes(m.profile.id)
                    ? ids.filter((id) => id !== m.profile.id)
                    : [...ids, m.profile.id].slice(0, 3),
                )
              }
              onTool={(type) => setTool({ type, match: m })}
              index={i}
              busy={busyId === m.profile.id || loading}
              onAction={(a) => action(m, a)}
              onReject={() => setSelected(m)}
            />
          ))}
          {!shown.length && (
            <Empty title="All clear here">Choose another view or client to continue.</Empty>
          )}
          {shown.length > limit && (
            <button className="button load-more" onClick={() => setLimit((n) => n + 8)}>
              Show more profiles ({shown.length - limit} remaining)
            </button>
          )}
        </div>
        <aside className="queue-aside">
          <section className="card">
            <div className="icon-tile">
              <SlidersHorizontal size={20} />
            </div>
            <h3>Your next steps</h3>
            <ol className="next-steps">
              <li>
                <strong>Review the profile</strong>
                <p>Read why it fits and check any open questions.</p>
              </li>
              <li>
                <strong>Save a possibility</strong>
                <p>Use Shortlist to keep a profile for later.</p>
              </li>
              <li>
                <strong>Record an introduction</strong>
                <p>After sending a profile by email, choose Mark shared.</p>
              </li>
            </ol>
            <details className="ranking-help">
              <summary>How ranking works</summary>
              <div className="weight-list">
                {[
                  ["Soft preferences", 45],
                  ["Values & lifestyle", 25],
                  ["Reviewed history", 20],
                  ["Profile completeness", 10],
                ].map(([label, weight]) => (
                  <div key={label}>
                    <span>{label}</span>
                    <strong>{weight}%</strong>
                  </div>
                ))}
              </div>
              <small>
                These are transparent starting weights, not a trained compatibility model.
              </small>
            </details>
          </section>
          <section className="queue-tip">
            <Sparkles size={18} />
            <h3>There’s more to a match.</h3>
            <p>
              Use the score as a starting point. Read the context, notice the unknowns, and bring
              your judgment.
            </p>
          </section>
        </aside>
      </div>
      {selected && (
        <FeedbackModal
          client={data.client}
          match={selected}
          onClose={() => setSelected(null)}
          onSaved={() => {
            setSelected(null);
            refresh();
            setMessage("Feedback saved. Preference signals have been recalculated.");
          }}
        />
      )}
      {tool?.type === "compare" && (
        <CompareDialog
          client={data.client}
          matches={all.filter((m) => compareIds.includes(m.profile.id))}
          onClose={() => setTool(null)}
        />
      )}
      {tool?.type === "preview" && (
        <WhatIfDialog client={data.client} matches={all} onClose={() => setTool(null)} />
      )}
      {tool?.type === "draft" && (
        <IntroductionDialog client={data.client} match={tool.match} onClose={() => setTool(null)} />
      )}
      {tool?.type === "compatibility" && (
        <CompatibilityDialog
          client={data.client}
          match={tool.match}
          onClose={() => setTool(null)}
          onSaved={() => {
            setTool(null);
            refresh();
            setMessage("Verified information saved. Two-sided checks updated.");
          }}
        />
      )}
      <Toast message={message} />
    </>
  );
}
