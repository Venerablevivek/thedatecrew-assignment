"use client";
import AIStatus from "@/components/AIStatus";
import { useState } from "react";
import Link from "next/link";
import { ArrowUpRight, MessageSquareText, ShieldCheck, Sparkles } from "lucide-react";
import {
  useResource,
  PageHeader,
  Loading,
  ErrorState,
  SectionTitle,
  Badge,
  Empty,
} from "@/components/ui";
import { ReasonChart } from "@/components/Charts";
import { pretty } from "@/lib/matching";
export default function Feedback() {
  const { data, loading, error, refresh } = useResource("/api/dashboard");
  const [category, setCategory] = useState("ALL"),
    [search, setSearch] = useState("");
  if (loading && !data) return <Loading />;
  if (error) return <ErrorState message={error} retry={refresh} />;
  if (!data) return null;
  const entries = data.feedback.filter(
    (f) =>
      (category === "ALL" || f.structured.reasons.some((r) => r.category === category)) &&
      `${f.client.name} ${f.rawText}`.toLowerCase().includes(search.toLowerCase()),
  );
  return (
    <>
      <PageHeader
        eyebrow="LISTEN. LEARN. REFINE."
        title="Learn from client feedback"
        description="Review rejection reasons and spot preferences that need a conversation."
      >
        <Badge tone="violet">
          {data.aiMode === "GEMINI"
            ? "Gemini key configured"
            : data.aiMode === "DEMO_RULES"
              ? "Demo rules · AI not connected"
              : "Manual categorization"}
        </Badge>
      </PageHeader>
      <AIStatus />
      <div className="feedback-overview">
        <section className="card">
          <SectionTitle
            title="The themes behind the feedback"
            subtitle="Live demo · counts update after each confirmed decision."
          />
          <ReasonChart data={data.rejectionReasons} />
        </section>
        <section className="feedback-opportunity">
          <ShieldCheck size={23} />
          <div className="big-number">{data.metrics.avoidableRejectionRate}%</div>
          <h2>We already had the context.</h2>
          <p>
            {data.metrics.knownRejections} of {data.metrics.rejected} explicit client rejections
            referenced a known preference.
          </p>
          <small>Internal screening decisions are excluded from this rate.</small>
          <Link href="/match-queue" className="text-link">
            Act on the insight
            <ArrowUpRight size={16} />
          </Link>
        </section>
      </div>
      <section className="card">
        <SectionTitle
          title="Signals worth a conversation"
          subtitle="Observed patterns, ready for a matchmaker’s judgment."
        />
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Client</th>
                <th>Observed pattern</th>
                <th>Evidence</th>
                <th>Status</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {data.signals.slice(0, 12).map((s) => (
                <tr key={s.id}>
                  <td>
                    <strong>{s.client.name}</strong>
                  </td>
                  <td>{s.title}</td>
                  <td>{s.evidence.count} decisions</td>
                  <td>
                    <Badge tone={s.status === "PENDING_REVIEW" ? "violet" : "neutral"}>
                      {pretty(s.status)}
                    </Badge>
                  </td>
                  <td>
                    <Link href={`/clients/${s.clientId}`} className="text-link">
                      Review
                      <ArrowUpRight size={14} />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section className="card feedback-library">
        <SectionTitle
          title="The feedback library"
          subtitle="Original words and reviewed interpretations, side by side."
        />
        <div className="list-toolbar">
          <input
            aria-label="Search feedback"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search clients or feedback…"
          />
          <select
            aria-label="Filter feedback category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="ALL">All categories</option>
            {data.rejectionReasons.map((r) => (
              <option value={r.category} key={r.category}>
                {pretty(r.category)}
              </option>
            ))}
          </select>
        </div>
        {entries.slice(0, 30).map((f) => (
          <div className="feedback-entry" key={f.id}>
            <div className="spread">
              <strong>
                {f.client.name}
                <span className="muted"> on {f.recommendation.profile.name}</span>
              </strong>
              <Badge>
                {["GEMINI", "OPENAI"].includes(f.source)
                  ? "AI + human review"
                  : f.source === "DEMO_RULES"
                    ? "Demo rules + human review"
                    : "Manual review"}
              </Badge>
            </div>
            <blockquote>“{f.rawText}”</blockquote>
            <div className="chip-row">
              {f.structured.reasons.map((r, i) => (
                <Badge key={i} tone={r.knownPreference ? "rose" : "violet"}>
                  {pretty(r.category)}
                  {r.knownPreference ? " · Known preference" : ""}
                </Badge>
              ))}
            </div>
          </div>
        ))}
        {!entries.length && (
          <Empty title="No matching feedback">Try another category or search.</Empty>
        )}
        {entries.length > 30 && (
          <p className="caption">Showing the 30 most recent matching records.</p>
        )}
      </section>
    </>
  );
}
