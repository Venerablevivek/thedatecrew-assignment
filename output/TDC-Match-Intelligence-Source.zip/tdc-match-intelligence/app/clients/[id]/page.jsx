"use client";
import { use, useState } from "react";
import Link from "next/link";
import { ArrowLeft, ArrowRight, LockKeyhole, MapPin, Sparkles, CheckCircle2 } from "lucide-react";
import {
  useResource,
  PageHeader,
  Loading,
  ErrorState,
  Avatar,
  Badge,
  SectionTitle,
  Empty,
} from "@/components/ui";
import { preferenceLabel, pretty } from "@/lib/matching";
import SignalCard from "@/components/SignalCard";
export default function ClientPage({ params }) {
  const { id } = use(params);
  const { data, loading, error, refresh } = useResource(`/api/clients/${id}`);
  const [tab, setTab] = useState("Intelligence");
  if (loading && !data) return <Loading />;
  if (error) return <ErrorState message={error} retry={refresh} />;
  if (!data) return null;
  const c = data.client;
  return (
    <>
      <Link href="/clients" className="back-link">
        <ArrowLeft size={15} />
        All clients
      </Link>
      <div className="client-heading">
        <Avatar name={c.name} large />
        <div>
          <div className="eyebrow">CLIENT INTELLIGENCE</div>
          <h1>{c.name}</h1>
          <p>
            {c.age} · {c.occupation} · {c.city}
          </p>
        </div>
        <Link href={`/match-queue?clientId=${c.id}`} className="button primary">
          Find introductions
          <ArrowRight size={16} />
        </Link>
      </div>
      <div className="client-meta">
        <span className="status-dot" />
        Active client<span>Managed by {c.matchmaker.name}</span>
        <span>Synthetic profile</span>
      </div>
      <div className="tabs">
        {["Intelligence", "Recommendations", "Feedback"].map((t) => (
          <button key={t} className={tab === t ? "active" : ""} onClick={() => setTab(t)}>
            {t}
            {t === "Feedback" && <span>{c.feedback.length}</span>}
          </button>
        ))}
      </div>
      {tab === "Intelligence" ? (
        <div className="intelligence-grid">
          <div className="stack">
            <section className="card">
              <SectionTitle
                title="What matters most"
                subtitle="Explicit requirements that every recommendation must meet."
              />
              <div className="preference-list">
                {c.preferences
                  .filter((p) => p.type === "HARD")
                  .map((p) => (
                    <div className="preference-row" key={p.id}>
                      <span className="preference-icon">
                        <LockKeyhole size={17} />
                      </span>
                      <div>
                        <strong>{preferenceLabel(p)}</strong>
                        <small>Stated by client</small>
                      </div>
                      <Badge>Strict</Badge>
                    </div>
                  ))}
              </div>
              <div className="card-foot">
                <LockKeyhole size={13} />A missing required field needs clarification before
                sharing.
              </div>
            </section>
            <section className="card">
              <SectionTitle
                title="Room for connection"
                subtitle="Soft preferences guide the ranking; they don’t exclude people."
              />
              <div className="preference-list">
                {c.preferences
                  .filter((p) => p.type === "SOFT")
                  .map((p) => (
                    <div className="preference-row" key={p.id}>
                      <span className="preference-icon soft">
                        <Sparkles size={17} />
                      </span>
                      <div>
                        <strong>{preferenceLabel(p)}</strong>
                        <small>
                          {p.source === "HUMAN_CONFIRMED"
                            ? "Updated after human confirmation"
                            : "Client-stated preference"}
                        </small>
                      </div>
                      <Badge tone="violet">{p.weight < 0.5 ? "Flexible" : "High priority"}</Badge>
                    </div>
                  ))}
              </div>
            </section>
            <section className="card">
              <SectionTitle
                title="Recent introductions"
                link="Open match queue"
                href={`/match-queue?clientId=${id}`}
              />
              <RecommendationTable records={c.recommendations.slice(0, 5)} />
            </section>
          </div>
          <aside className="stack">
            <div className="section-title">
              <div>
                <h2>A second perspective</h2>
                <p>Patterns for a human to review.</p>
              </div>
            </div>
            {c.signals.map((s) => (
              <SignalCard key={s.id} signal={s} onChange={refresh} />
            ))}
            {!c.signals.length && (
              <Empty title="Still getting to know this client">
                Signals appear when enough reviewed decisions support a pattern.
              </Empty>
            )}
            <div className="subtle-note">
              <CheckCircle2 size={18} />
              <p>Evidence comes first. Signals never silently change a client’s preferences.</p>
            </div>
          </aside>
        </div>
      ) : tab === "Recommendations" ? (
        <section className="card">
          <SectionTitle
            title="Recommendation history"
            subtitle="Milestones are recorded separately so later outcomes preserve the funnel."
          />
          <RecommendationTable records={c.recommendations} />
        </section>
      ) : (
        <section className="card">
          <SectionTitle
            title="The client’s own words"
            subtitle="Original feedback, kept alongside the reviewed interpretation."
          />
          {c.feedback.map((f) => (
            <div className="feedback-entry" key={f.id}>
              <blockquote>“{f.rawText}”</blockquote>
              <div className="chip-row">
                {f.structured.reasons.map((r, i) => (
                  <Badge key={i} tone="violet">
                    {pretty(r.category)} · {r.label}
                  </Badge>
                ))}
              </div>
              <small>
                {["GEMINI", "OPENAI"].includes(f.source)
                  ? "AI draft reviewed"
                  : f.source === "DEMO_RULES"
                    ? "Demo rule draft reviewed"
                    : "Manually reviewed"}
              </small>
            </div>
          ))}
        </section>
      )}
    </>
  );
}
function RecommendationTable({ records }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Profile</th>
            <th>Location</th>
            <th>Latest outcome</th>
          </tr>
        </thead>
        <tbody>
          {records.map((r) => (
            <tr key={r.id}>
              <td>
                <strong>{r.profile.name}</strong>
                <small>
                  {r.profile.age} · {r.profile.occupation}
                </small>
              </td>
              <td>{r.profile.city}</td>
              <td>
                <Badge tone={r.acceptedAt ? "green" : r.status === "REJECTED" ? "rose" : "neutral"}>
                  {pretty(r.status)}
                </Badge>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
