"use client";
import { useState } from "react";
import Link from "next/link";
import { Search, ArrowUpRight, UsersRound, Sparkles } from "lucide-react";
import {
  useResource,
  PageHeader,
  Loading,
  ErrorState,
  Avatar,
  Badge,
  Empty,
} from "@/components/ui";
export default function Clients() {
  const { data, loading, error, refresh } = useResource("/api/clients");
  const [search, setSearch] = useState("");
  if (loading && !data) return <Loading />;
  if (error) return <ErrorState message={error} retry={refresh} />;
  const clients =
    data?.clients.filter((c) =>
      `${c.name} ${c.city} ${c.occupation}`.toLowerCase().includes(search.toLowerCase()),
    ) || [];
  return (
    <>
      <PageHeader
        eyebrow="YOUR PEOPLE"
        title="Choose a client"
        description="Open a client to review their preferences and find suitable profiles."
      >
        <Badge tone="violet">{data?.clients.length} active clients</Badge>
      </PageHeader>
      <div className="list-toolbar">
        <label className="search-box">
          <Search size={17} />
          <input
            aria-label="Search clients"
            placeholder="Search by name, city, or profession…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </label>
        <span className="caption">All matchmakers · Synthetic profiles</span>
      </div>
      <div className="client-grid">
        {clients.map((c, i) => (
          <Link className="card client-card" key={c.id} href={`/clients/${c.id}`}>
            <div className="spread">
              <Avatar name={c.name} index={i} large />
              <ArrowUpRight className="muted" size={20} />
            </div>
            <h2>{c.name}</h2>
            <p>
              {c.age} · {c.occupation}
            </p>
            <p className="muted">{c.city}</p>
            <div className="client-card-stats">
              <div>
                <strong>{c.acceptanceRate}%</strong>
                <small>Acceptance</small>
              </div>
              <div>
                <strong>{c.recommendations.length}</strong>
                <small>Recommendations</small>
              </div>
            </div>
            <div className="spread">
              <small>{c.matchmaker.name.split(" · ")[0]}</small>
              {c.pendingSignals > 0 ? (
                <Badge tone="violet">
                  <Sparkles size={12} />
                  {c.pendingSignals} to review
                </Badge>
              ) : (
                <Badge>Up to date</Badge>
              )}
            </div>
          </Link>
        ))}
      </div>
      {!clients.length && <Empty title="No clients found">Try a different name or city.</Empty>}
    </>
  );
}
